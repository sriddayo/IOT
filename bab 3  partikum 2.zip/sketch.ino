// =================================================
// Praktikum 2: LED Eksternal - Pola Kedip Bervariasi
// =================================================

#define LED_EXT 5      // LED merah eksternal di GPIO 5
#define LED_INT 2      // LED ungu di GPIO 2 (nyala terus)

int polaBlink = 1;     // variabel untuk memilih pola

// Fungsi: blink cepat sebanyak n kali
void blinkCepat(int n) {
  for (int i = 0; i < n; i++) {
    digitalWrite(LED_EXT, HIGH);
    delay(100);
    digitalWrite(LED_EXT, LOW);
    delay(100);
  }
}

// Fungsi: blink lambat sebanyak n kali
void blinkLambat(int n) {
  for (int i = 0; i < n; i++) {
    digitalWrite(LED_EXT, HIGH);
    delay(800);
    digitalWrite(LED_EXT, LOW);
    delay(800);
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(LED_EXT, OUTPUT);
  pinMode(LED_INT, OUTPUT);
  
  // Menyalakan LED ungu (GPIO 2) secara permanen sejak program mulai
  digitalWrite(LED_INT, HIGH);
  
  Serial.println("Program Pola Blink Dimulai!");
}

void loop() {
  Serial.print("Menjalankan pola ke-");
  Serial.println(polaBlink);

  if (polaBlink == 1) {
    Serial.println("Pola 1: Blink Cepat 5x");
    blinkCepat(5);
  } else if (polaBlink == 2) {
    Serial.println("Pola 2: Blink Lambat 3x");
    blinkLambat(3);
  } else {
    Serial.println("Pola 3: LED Nyala 2 detik");
    digitalWrite(LED_EXT, HIGH);
    delay(2000);
    digitalWrite(LED_EXT, LOW);
  }

  polaBlink++;          // Pindah ke pola berikutnya
  if (polaBlink > 3) {
    polaBlink = 1;      // Kembali ke pola 1
  }

  delay(500);           // Jeda antar pola
}